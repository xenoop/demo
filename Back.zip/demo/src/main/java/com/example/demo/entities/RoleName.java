package com.example.demo.entities;

public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}